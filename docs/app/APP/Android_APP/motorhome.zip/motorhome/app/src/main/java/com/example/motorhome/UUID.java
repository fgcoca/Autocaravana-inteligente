package com.example.motorhome;

public class UUID {
    public static final String serverUuid = "0000ffe0-0000-1000-8000-00805f9b34fb";
    public static final String charaUuid = "0000ffe1-0000-1000-8000-00805f9b34fb";
}
