package com.example.motorhome;

import android.annotation.TargetApi;
import android.hardware.Sensor;
import android.hardware.SensorManager;


import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.LocationManager;
import android.os.Build;
import android.os.Handler;
import android.os.Message;

import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class MainActivity extends AppCompatActivity{

    float Azimuth = 0;
    float Tilt = 0;
    float Roll = 0;
    int flag1 = 0;
    int flag2 = 0;
    int flag3 = 0;
    int flag4 = 0;
    int i =0;

    int flag_neo1 = 0;
    int flag_neo2 = 0;
    int flag_neo3 = 0;

    int i1 = 0;
    int i11 = 0;
    int i2 = 0;
    int i22 = 0;
    int i3 = 0;
    int i33 = 0;
    int i4 = 0;
    int i44 = 0;


    private TextView tv_value1;
    private TextView tv_value2;
    private TextView tv_value3;
    private SensorManager sManager;
    private Sensor mSensorOrientation;

    private TextView light_value;  //用于显示光敏值
    private TextView gas_value; //用于显示危险气体值
    private TextView water_value;  //用于显示土壤湿度值
    private TextView body_value;  //用于显示是否有人
    private TextView humidity_value;
    private TextView temp_value;
    private TextView speed_value;

    private  TextView door_value;  //门的值
    private  TextView window_value; //窗户的值
    private  TextView servo3_value;
    private  TextView red_value;
    private  TextView green_value;
    private  TextView blue_value;

    private SeekBar door_bar;
    private SeekBar win_bar;
    private SeekBar servo3_bar;
    private SeekBar red_bar;
    private SeekBar green_bar;
    private SeekBar blue_bar;

    private Context mContext;

    //字符串变量，用于seekbar拖动条的整型转字符串
    String door_str;
    String win_str;
    String servo3_str;
    String red_str;
    String green_str;
    String blue_str;

    @TargetApi(Build.VERSION_CODES.CUPCAKE)

    /**
     * 蓝牙的基本操作，比如打开等
     */
    private BluetoothAdapter bluetoothAdapter;
    private int REQUEST_ENABLE_BT = 0;
    private long SCAN_PERIOD = 30000;
    private boolean mScanning;
    private ArrayList<BluetoothDevice> bluetoothDeviceArrayList = new ArrayList<>();
    private device adapter;

    /**
     * 蓝牙设备
     */
    private BluetoothDevice mBluetoothDevice;
    /**
     * 数据的读写操作
     */
    private BluetoothGattCharacteristic characteristic;
    /**
     * 连接蓝牙设备 重连等操作
     */
    private BluetoothGatt mBluetoothGatt;
    private List<BluetoothGatt> bluetoothGattList;
    public static final int PERMISSIONS_REQUEST_CODE = 101;
    /**
     * 扫描回调
     */
    private BluetoothAdapter.LeScanCallback mLeScanCallback = new BluetoothAdapter.LeScanCallback() {
        @Override
        public void onLeScan(BluetoothDevice bluetoothDevice, int i, byte[] bytes) {
            if (bluetoothDevice.getName() != null) {
                if (!bluetoothDeviceArrayList.contains(bluetoothDevice)) {
                    bluetoothDeviceArrayList.add(bluetoothDevice);
                }
                Log.e(TAG, "scan--" + bluetoothDevice.getName());
            }
        }
    };

    private Handler adapterFreshHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            adapter.notifyDataSetChanged();
        }
    };

    //获取蓝牙设备并返回
    public BluetoothDevice getmBluetoothDevice() {
        return mBluetoothDevice;
    }
    //获取蓝牙特征值并返回
    public BluetoothGattCharacteristic getCharacteristic() {
        return characteristic;
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button disconnect = findViewById(R.id.disconnect);
        disconnect.setEnabled(false);


        registerBleListenerReceiver();
        //位置权限
        int check = ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION);
        if (check == PackageManager.PERMISSION_GRANTED) {
            initBlueTooth();
        } else {
            //获取权限 这里需请求精确定位权限, Manifest.permission.WRITE_CONTACTS, Manifest.permission.ACCESS_FINE_LOCATION
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_COARSE_LOCATION,Manifest.permission.WRITE_CONTACTS, Manifest.permission.ACCESS_FINE_LOCATION}, PERMISSIONS_REQUEST_CODE);
        }

        //动态申请权限

        // Android 6.0动态请求权限
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
//            String[] permissions = {Manifest.permission.WRITE_EXTERNAL_STORAGE
//                    , Manifest.permission.READ_EXTERNAL_STORAGE
//                    , Manifest.permission.ACCESS_COARSE_LOCATION,Manifest.permission.ACCESS_FINE_LOCATION};
//            for (String str : permissions) {
//                if (checkSelfPermission(str) != PackageManager.PERMISSION_GRANTED) {
//                    requestPermissions(permissions, 111);
//                    break;
//                }
//            }
//        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P){
            LocationManager alm = (LocationManager)MainActivity.this.getSystemService(Context.LOCATION_SERVICE);
            if (!alm.isProviderEnabled(android.location.LocationManager.GPS_PROVIDER)){
                Toast.makeText(this, "Please turn on the GPS!", Toast.LENGTH_SHORT).show();
            }
        }


        light_value = findViewById(R.id.light_text_id);   //光敏
        //light_value.setText("light");
        gas_value = findViewById(R.id.gas_text_id);
        water_value = findViewById(R.id.water_text_id);
        humidity_value = findViewById(R.id.humidity_text_id);
        temp_value = findViewById(R.id.temp_text_id);
        body_value = findViewById(R.id.body_text_id);
        speed_value = findViewById(R.id.speed_text_id);


        new TimeThread().start();//启动线程



        addListener();

        iotView();
        gameView();
        iot_return_ble();
        game_return_ble();

        sendF1();    //按下发送F,松开发送S
        sendB1();
        sendL1();
        sendR1();
        speed_sub();
        speed_add();

        send_do();
        send_re();
        send_mi();
        send_fa();
        send_so();
        send_la();
        send_si();

        send_orange();
        send_blue();
        send_cyan();
        send_green();
        send_purple();
        send_red();
        send_yellow();

        avoid_car();
        follow_car();
        track_car();

        neo_add();
        neo_sub();
        neo_stop();

        modeMusic();
        modeNeo();
        modeMode();
        modeRgb();
        disconnect();  //断开蓝牙

        home_led();
        home_neo();
        home_music();
        home_humidity();
        home_body();
        home_light();
        home_gas();
        home_water();
        home_temp();
        home_door();
        home_window();
        home_servo3();
        home_red();
        home_green();
        home_blue();

        door_seek_val();
        window_seek_val();
        servo3_seek_val();
        red_seek_val();
        green_seek_val();
        blue_seek_val();

       /* Button return001 = findViewById(R.id.rtn);
        return001.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Intent play_piano = new Intent(MainActivity.this, PlayMusic.class);

                //打开新界面
                //startActivity(play_piano);
                View view3 = findViewById(R.id.view3);
                view3.setVisibility(View.VISIBLE);

                View view2 = findViewById(R.id.view2);
                view2.setVisibility(View.GONE);
            }
        });*/
    }

    //写一个新的线程每隔一秒发送一次消息,这样做会和系统时间相差1秒
    int mode = 0;
    public class TimeThread extends Thread{
        @Override
        public void run() {
            super.run();
            do{
                try {
                    Thread.sleep(100);   //延时
                    Message msg = new Message();
                    msg.what = mode;
                    handler.sendMessage(msg);

                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }while (true);

        }
    }

    //点击打开gameView界面
    private void gameView() {
        findViewById(R.id.game_btn).setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent)
            {   //
                if(motionEvent.getAction() == MotionEvent.ACTION_DOWN)
                {
                    View v = findViewById(R.id.game_btn);
                    v.getBackground().setAlpha(100);
                    //String writeStr = "U";
                    //writeCmd(writeStr.getBytes());
                }
                if(motionEvent.getAction() == MotionEvent.ACTION_UP)
                {
                    View v = findViewById(R.id.game_btn);
                    v.getBackground().setAlpha(255);
                    //String writeStr = "U";
                    //writeCmd(writeStr.getBytes());
                    //打开新界面
                    View game_view = findViewById(R.id.game_view);
                    game_view.setVisibility(View.VISIBLE);
                    View iot_view = findViewById(R.id.iot_view);
                    iot_view.setVisibility(View.GONE);
                    View ble_view = findViewById(R.id.select_view);
                    ble_view.setVisibility(View.GONE);
                }
                return false;
            }
        });
    }

    //点击打开iotView界面
    private void iotView() {
        findViewById(R.id.home_btn).setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent)
            {   //
                if(motionEvent.getAction() == MotionEvent.ACTION_DOWN)
                {
                    View v = findViewById(R.id.home_btn);
                    v.getBackground().setAlpha(100);
                    //String writeStr = "U";
                    //writeCmd(writeStr.getBytes());
                }
                if(motionEvent.getAction() == MotionEvent.ACTION_UP)
                {
                    View v = findViewById(R.id.home_btn);
                    v.getBackground().setAlpha(255);
                    //String writeStr = "U";
                    //writeCmd(writeStr.getBytes());
                    //打开新界面
                    View game_view = findViewById(R.id.game_view);
                    game_view.setVisibility(View.GONE);
                    View iot_view = findViewById(R.id.iot_view);
                    iot_view.setVisibility(View.VISIBLE);
                    View ble_view = findViewById(R.id.select_view);
                    ble_view.setVisibility(View.GONE);
                }
                return false;
            }
        });
    }

    //点击从gameView返回ble_View界面
    private void game_return_ble() {
        findViewById(R.id.game_return).setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent)
            {   //
                if(motionEvent.getAction() == MotionEvent.ACTION_DOWN)
                {
                    View v = findViewById(R.id.game_return);
                    v.getBackground().setAlpha(100);
                    //String writeStr = "U";
                    //writeCmd(writeStr.getBytes());
                }
                if(motionEvent.getAction() == MotionEvent.ACTION_UP)
                {
                    View v = findViewById(R.id.game_return);
                    v.getBackground().setAlpha(255);
                    //String writeStr = "U";
                    //writeCmd(writeStr.getBytes());
                    //打开新界面
                    View game_view = findViewById(R.id.game_view);
                    game_view.setVisibility(View.GONE);
                    View iot_view = findViewById(R.id.iot_view);
                    iot_view.setVisibility(View.GONE);
                    View ble_view = findViewById(R.id.select_view);
                    ble_view.setVisibility(View.VISIBLE);
                }
                return false;
            }
        });
    }

    //点击从iotView返回ble_View界面
    private void iot_return_ble() {
        findViewById(R.id.iot_return).setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent)
            {   //
                if(motionEvent.getAction() == MotionEvent.ACTION_DOWN)
                {
                    View v = findViewById(R.id.iot_return);
                    v.getBackground().setAlpha(100);
                    //String writeStr = "U";
                    //writeCmd(writeStr.getBytes());
                }
                if(motionEvent.getAction() == MotionEvent.ACTION_UP)
                {
                    View v = findViewById(R.id.iot_return);
                    v.getBackground().setAlpha(255);
                    //String writeStr = "U";
                    //writeCmd(writeStr.getBytes());
                    //打开新界面
                    View game_view = findViewById(R.id.game_view);
                    game_view.setVisibility(View.GONE);
                    View iot_view = findViewById(R.id.iot_view);
                    iot_view.setVisibility(View.GONE);
                    View ble_view = findViewById(R.id.select_view);
                    ble_view.setVisibility(View.VISIBLE);
                }
                return false;
            }
        });
    }

    //点击music按钮，打开music界面
    private void modeMusic() {
        findViewById(R.id.mode_music).setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent)
            {   //
                if(motionEvent.getAction() == MotionEvent.ACTION_DOWN)
                {
                    View v = findViewById(R.id.mode_music);
                    v.getBackground().setAlpha(100);
                    //String writeStr = "U";
                    //writeCmd(writeStr.getBytes());
                }
                if(motionEvent.getAction() == MotionEvent.ACTION_UP)
                {
                    View v = findViewById(R.id.mode_music);
                    v.getBackground().setAlpha(255);
                    //String writeStr = "U";
                    //writeCmd(writeStr.getBytes());
                    //打开新界面
                    View music_view = findViewById(R.id.car_music);
                    music_view.setVisibility(View.VISIBLE);
                    View mode_view = findViewById(R.id.car_mode);
                    mode_view.setVisibility(View.GONE);
                    View rgb_view = findViewById(R.id.car_rgb);
                    rgb_view.setVisibility(View.GONE);
                    View neo_view = findViewById(R.id.car_neo);
                    neo_view.setVisibility(View.GONE);
                }
                return false;
            }
        });
    }

    //点击neo按钮，打开neo界面
    private void modeNeo() {
        findViewById(R.id.mode_neo).setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent)
            {   //
                if(motionEvent.getAction() == MotionEvent.ACTION_DOWN)
                {
                    View v = findViewById(R.id.mode_neo);
                    v.getBackground().setAlpha(100);
                    //String writeStr = "U";
                    //writeCmd(writeStr.getBytes());
                }
                if(motionEvent.getAction() == MotionEvent.ACTION_UP)
                {
                    View v = findViewById(R.id.mode_neo);
                    v.getBackground().setAlpha(255);
                    //String writeStr = "U";
                    //writeCmd(writeStr.getBytes());
                    //打开新界面
                    View music_view = findViewById(R.id.car_music);
                    music_view.setVisibility(View.GONE);
                    View mode_view = findViewById(R.id.car_mode);
                    mode_view.setVisibility(View.GONE);
                    View rgb_view = findViewById(R.id.car_rgb);
                    rgb_view.setVisibility(View.GONE);
                    View neo_view = findViewById(R.id.car_neo);
                    neo_view.setVisibility(View.VISIBLE);
                }
                return false;
            }
        });
    }


    //点击rgb按钮，打开rgb界面
    private void modeRgb() {
        findViewById(R.id.mode_rgb).setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent)
            {   //
                if(motionEvent.getAction() == MotionEvent.ACTION_DOWN)
                {
                    View v = findViewById(R.id.mode_rgb);
                    v.getBackground().setAlpha(100);
                    //String writeStr = "U";
                    //writeCmd(writeStr.getBytes());
                }
                if(motionEvent.getAction() == MotionEvent.ACTION_UP)
                {
                    View v = findViewById(R.id.mode_rgb);
                    v.getBackground().setAlpha(255);
                    //String writeStr = "U";
                    //writeCmd(writeStr.getBytes());
                    //打开新界面
                    View music_view = findViewById(R.id.car_music);
                    music_view.setVisibility(View.GONE);
                    View mode_view = findViewById(R.id.car_mode);
                    mode_view.setVisibility(View.GONE);
                    View rgb_view = findViewById(R.id.car_rgb);
                    rgb_view.setVisibility(View.VISIBLE);
                    View neo_view = findViewById(R.id.car_neo);
                    neo_view.setVisibility(View.GONE);
                }
                return false;
            }
        });
    }

    //点击mode按钮，打开mode界面
    private void modeMode() {
        findViewById(R.id.mode_btn).setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent)
            {   //
                if(motionEvent.getAction() == MotionEvent.ACTION_DOWN)
                {
                    View v = findViewById(R.id.mode_btn);
                    v.getBackground().setAlpha(100);
                    //String writeStr = "U";
                    //writeCmd(writeStr.getBytes());
                }
                if(motionEvent.getAction() == MotionEvent.ACTION_UP)
                {
                    View v = findViewById(R.id.mode_btn);
                    v.getBackground().setAlpha(255);
                    //String writeStr = "U";
                    //writeCmd(writeStr.getBytes());
                    //打开新界面
                    View music_view = findViewById(R.id.car_music);
                    music_view.setVisibility(View.GONE);
                    View mode_view = findViewById(R.id.car_mode);
                    mode_view.setVisibility(View.VISIBLE);
                    View rgb_view = findViewById(R.id.car_rgb);
                    rgb_view.setVisibility(View.GONE);
                    View neo_view = findViewById(R.id.car_neo);
                    neo_view.setVisibility(View.GONE);
                }
                return false;
            }
        });
    }

    /**
     * 初始化蓝牙
     */
    private void initBlueTooth() {
        //获取蓝牙管理权限
        BluetoothManager manager = (BluetoothManager) getSystemService(BLUETOOTH_SERVICE);
        if (manager != null) {
            //获取蓝牙适配器
            bluetoothAdapter = manager.getAdapter();

            if (bluetoothAdapter != null) {
                //蓝牙没有打开
                if (!bluetoothAdapter.isEnabled()) {
                    openBle(); //打开蓝牙
                } else {
                    Toast.makeText(MainActivity.this, "Bluetooth enabled", Toast.LENGTH_SHORT).show();
                    scanLeDevice(true);
                }
            } else {
                openBle();
            }
        }
        adapter = new device(bluetoothDeviceArrayList, MainActivity.this);
        bluetoothGattList = new ArrayList<>();
    }

    /**
     * 解决：android 10   targetSdkVersion 29  无法发现蓝牙设备的问题
     *
     * 对于发现新设备这个功能, 还需另外两个权限(Android M 以上版本需要显式获取授权,附授权代码):
     */
//    private final int ACCESS_LOCATION=1;
//    @SuppressLint("WrongConstant")
//    private void getPermission() {
//        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.M) {
//            int permissionCheck = 0;
//            permissionCheck = this.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION);
//            permissionCheck += this.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION);
//
//            if (permissionCheck != PackageManager.PERMISSION_GRANTED) {
//                //未获得权限
//                this.requestPermissions( // 请求授权
//                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
//                                Manifest.permission.ACCESS_COARSE_LOCATION},
//                        ACCESS_LOCATION);// 自定义常量,任意整型
//            }
//        }
//    }


    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSIONS_REQUEST_CODE) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                initBlueTooth();
            } else {
                Toast.makeText(this, "Location permission not obtained", Toast.LENGTH_SHORT).show();
            }
        }
    }

//    private boolean hasAllPermissionGranted(int[] grantResults) {
//        for (int grantResult : grantResults) {
//            if (grantResult == PackageManager.PERMISSION_DENIED) {
//                return false;
//            }
//        }
//        return true;
//    }

    private void addListener() {   //打开搜索蓝牙界面
        findViewById(R.id.scan).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                adapter.notifyDataSetChanged();
                AlertDialog builder = new AlertDialog.Builder(MainActivity.this)
                        .setAdapter(adapter, null)
                        .create();
                builder.show();
                scanLeDevice(true);
            }
        });

    }



    private void disconnect() {
        findViewById(R.id.disconnect).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mBluetoothGatt.disconnect();
                Button disconnect = findViewById(R.id.disconnect);
                disconnect.setEnabled(false);
                disconnect.setTextColor(Color.parseColor("#808080"));
                Button connect = findViewById(R.id.scan);
                connect.setTextColor(Color.parseColor("#00BFFF"));  //断开连接，字体变蓝色
            }
        });

    }







    /**
     * 打开蓝牙
     */
    private void openBle() {
//        boolean enable = bluetoothAdapter.enable();//打开蓝牙'直接打开，用户不知权，用于定制系统'
//        Toast.makeText(MainActivity.this, "正在打开蓝牙", Toast.LENGTH_SHORT).show();
//        if (enable) {
//            Log.e("open",enable+"");
//            new Handler().postDelayed(new Runnable() {
//                @Override
//                public void run() {
//                    scanLeDevice(true);
//                }
//            },2000);
//
//        }
        Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);//提示用户正在打开蓝牙
        startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);


    }


    /**
     * 打开或者停止扫描
     *
     * @param enable
     */
    private void scanLeDevice(final boolean enable) {

        if (enable) {
            mScanning = true;
            // 定义一个回调接口供扫描结束处理
            bluetoothAdapter.startLeScan(mLeScanCallback);
            // 预先定义停止蓝牙扫描的时间（因为蓝牙扫描需要消耗较多的电量）
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    mScanning = false;
                    bluetoothAdapter.stopLeScan(mLeScanCallback);
                }
            }, SCAN_PERIOD);

        } else {
            mScanning = false;
            bluetoothAdapter.stopLeScan(mLeScanCallback);
        }
    }

    /**
     * 连接蓝牙
     */
    public void connectBle(BluetoothDevice bluetoothDevice) {
        mBluetoothDevice = bluetoothDevice;
        if (bluetoothDevice != null) {
            //第二个参数 是否重连
            mBluetoothGatt = bluetoothDevice.connectGatt(MainActivity.this, false, bluetoothGattCallback);
            bluetoothGattList.add(mBluetoothGatt);
            Button disconnect = findViewById(R.id.disconnect);
            disconnect.setEnabled(true);
            disconnect.setTextColor(Color.parseColor("#00BFFF"));
            Button connect = findViewById(R.id.scan);
            connect.setTextColor(Color.parseColor("#008000"));  //连接成功，字体变绿色
        }

    }

    /**
     * 断开蓝牙设备
     */
    public void bleDisConnectDevice(BluetoothDevice device) {
        if (mBluetoothGatt != null) {
            mBluetoothGatt.disconnect();
        }
    }


    private String TAG = "MainActivity";
    /**
     * 蓝牙连接成功回调
     */

    private BluetoothGattCallback bluetoothGattCallback = new BluetoothGattCallback() {
        @Override
        public void onPhyUpdate(BluetoothGatt gatt, int txPhy, int rxPhy, int status) {
            super.onPhyUpdate(gatt, txPhy, rxPhy, status);
        }

        @Override
        public void onPhyRead(BluetoothGatt gatt, int txPhy, int rxPhy, int status) {
            super.onPhyRead(gatt, txPhy, rxPhy, status);
        }

        //不要执行耗时操作
        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            super.onConnectionStateChange(gatt, status, newState);
            if (newState == BluetoothProfile.STATE_CONNECTED) {//连接成功
                Log.e(TAG, "onConnectionStateChange Bluetooth connection");
                gatt.discoverServices();
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                Log.e(TAG, "onConnectionStateChange Bluetooth connection");
                if (mBluetoothDevice != null) {//重新连接
                    //关闭当前新的连接
                    gatt.close();
                    characteristic = null;
                    adapterFreshHandler.sendEmptyMessage(0);
//                    connectBle(mBluetoothDevice);
                }

            }

        }

        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {//以上的方法gatt.discoverServices();才会回调
            super.onServicesDiscovered(gatt, status);
            //回调之后，设备之间才真正通信连接起来
            if (status == BluetoothGatt.GATT_SUCCESS) {
                Log.e(TAG, "onServicesDiscovered Bluetooth connection is normal");
                BluetoothGattService service = gatt.getService(UUID.fromString(com.example.motorhome.UUID.serverUuid));
                characteristic = service.getCharacteristic(UUID.fromString(com.example.motorhome.UUID.charaUuid));
                gatt.readCharacteristic(characteristic);//执行之后，会执行下面的onCharacteristicRead的回调方法
                setCharacteristicNotification(characteristic, true);
                adapterFreshHandler.sendEmptyMessage(0);
            } else {
                Log.e(TAG, "onServicesDiscovered Bluetooth connection failed");
            }

        }




        @Override
        public void onCharacteristicRead(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
            super.onCharacteristicRead(gatt, characteristic, status);
            Log.e(TAG, "callback characteristic read status " + status
                    + " in thread " + Thread.currentThread());
            if (status == BluetoothGatt.GATT_SUCCESS) {
                Log.e(TAG, "read value: " + characteristic.getValue());
            }


        }

        @Override
        public void onCharacteristicWrite(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
            super.onCharacteristicWrite(gatt, characteristic, status);
            Log.e(TAG, "write value: " + FormatUtil.bytesToHexString(characteristic.getValue()));
        }

        //设备发出通知时会调用到该接口
        @Override
        public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
            super.onCharacteristicChanged(gatt, characteristic);
            Log.e(TAG, "接收：" + FormatUtil.bytesToHexString(characteristic.getValue()));//byte[]转为16进制字符串
            bleWriteReceiveCallback();
        }


    };

    /**
     * 设置接收通知 即 另一端发送数据
     *
     * @param characteristic
     * @param enabled
     */
    public void setCharacteristicNotification(BluetoothGattCharacteristic characteristic, boolean enabled) {
        if (bluetoothAdapter == null || mBluetoothGatt == null) {
            return;
        }
        mBluetoothGatt.setCharacteristicNotification(characteristic, enabled);
//        BluetoothGattDescriptor descriptor = characteristic.getDescriptor(UUID
//                .fromString(BleConstantValue.charaUuid));
//        if (descriptor != null) {
//            descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
//            mBluetoothGatt.writeDescriptor(descriptor);
//        }

    }

    String num2 =  "";
    private Handler handler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(Message msg) {
            switch (msg.what){
                case 1:
                    //mainTv.setText(new SimpleDateFormat("HH:mm:ss").format(new Date(System.currentTimeMillis())));
                    light_value.setText(num2);    //刷新接收到的传感器数据
                    break;
                case 2:
                    gas_value.setText(num2);
                    break;
                case 3:
                    water_value.setText(num2);
                    break;
                case 4:
                    temp_value.setText(num2);
                    break;
                case 5:
                    humidity_value.setText(num2);
                    break;
                case 6:
                    body_value.setText(num2);
                    break;
                case 7:
                    speed_value.setText(num2);
                    break;
            }
            return false;
        }
    });


    /**
     * 写入：接受成功指令
     */
    public void bleWriteReceiveCallback() {
        num2 = FormatUtil.bytetoString(characteristic.getValue());
        Log.e(TAG, "接收到的数据：" + num2);
        //String writeStr = "REVOK\r\n";
        //writeCmd(writeStr.getBytes());
    }

    /**
     * 写入命令
     *
     * @param cmd
     */
    protected void writeCmd(byte[] cmd) {
        if (characteristic != null) {
            // 发出数据
            characteristic.setValue(cmd);
            if (mBluetoothGatt.writeCharacteristic(characteristic)) {
                Log.e(TAG, "Write to successful");
            } else {
                Log.e(TAG, "Write failed");
            }
        } else {
            Toast.makeText(MainActivity.this, "Bluetooth is not connected", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * 打开蓝牙的回调，一般打开后开始扫描
     *
     * @param requestCode
     * @param resultCode
     * @param data
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && requestCode == REQUEST_ENABLE_BT) {
            scanLeDevice(true);
        }
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        releaseResource();
        unregisterReceiver(bleListenerReceiver);

    }

    /**
     * 释放资源
     */

    private void releaseResource() {
        Log.e(TAG, "Disconnect the Bluetooth connection to release resources");
        for (BluetoothGatt gatt : bluetoothGattList) {
            if (gatt != null) {
                gatt.disconnect();
                gatt.close();

            }
        }
    }


    /**
     * 显示监听状态变化
     *
     * @param intent
     */
    private void showBleStateChange(Intent intent) {
        String action = intent.getAction();
        //连接的设备信息
        BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
        Log.e(TAG, "蓝牙监听广播…………………………" + action);

        if (mBluetoothDevice != null && mBluetoothDevice.equals(device)) {
            Log.e(TAG, "收到广播-->是当前连接的蓝牙设备");

            if (BluetoothDevice.ACTION_ACL_CONNECTED.equals(action)) {
                Log.e(TAG,"广播 蓝牙已经连接");

            } else if (BluetoothDevice.ACTION_ACL_DISCONNECTED.equals(action)) {
                Log.e(TAG,"广播 蓝牙断开连接");
            }
        } else {
            Log.e(TAG, "收到广播-->不是当前连接的蓝牙设备");
        }

        if (BluetoothAdapter.ACTION_STATE_CHANGED.equals(action)) {
            int state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, BluetoothAdapter.ERROR);
            switch (state) {
                case BluetoothAdapter.STATE_OFF:
                    Log.e(TAG, "STATE_OFF 蓝牙关闭");
                    adapter.clear();
                    releaseResource();
                    break;
                case BluetoothAdapter.STATE_TURNING_OFF:
                    Log.e(TAG, "STATE_TURNING_OFF 蓝牙正在关闭");
                    //停止蓝牙扫描
                    scanLeDevice(false);
                    break;
                case BluetoothAdapter.STATE_ON:
                    Log.d(TAG, "STATE_ON 蓝牙开启");
                    //扫描蓝牙设备
                    scanLeDevice(true);
                    break;
                case BluetoothAdapter.STATE_TURNING_ON:
                    Log.e(TAG, "STATE_TURNING_ON 蓝牙正在开启");
                    break;
            }
        }
    }

    /**
     * 蓝牙监听广播接受者
     */
    private BroadcastReceiver bleListenerReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            showBleStateChange(intent);
        }
    };

    /**
     * 注册蓝牙监听广播
     */
    private void registerBleListenerReceiver() {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(BluetoothAdapter.ACTION_STATE_CHANGED);
        intentFilter.addAction(BluetoothDevice.ACTION_ACL_CONNECTED);
        intentFilter.addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED);
        registerReceiver(bleListenerReceiver, intentFilter);
    }

    /////////////发送命令/////////////
    private void sendF1() {
        findViewById(R.id.car_f).setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent)
            {   //触摸，按住发送F,松开发送S
                if(motionEvent.getAction() == MotionEvent.ACTION_DOWN)
                {
                    View v = findViewById(R.id.car_f);
                    v.getBackground().setAlpha(100);
                    String writeStr = "F";
                    writeCmd(writeStr.getBytes());
                }
                if(motionEvent.getAction() == MotionEvent.ACTION_UP)
                {
                    View v = findViewById(R.id.car_f);
                    v.getBackground().setAlpha(255);
                    String writeStr = "S";
                    writeCmd(writeStr.getBytes());
                }
                return false;
            }

        });
    }

    private void sendB1() {
        findViewById(R.id.car_b).setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent)
            {   //触摸，按住发送F,松开发送S
                if(motionEvent.getAction() == MotionEvent.ACTION_DOWN)
                {
                    View v = findViewById(R.id.car_b);
                    v.getBackground().setAlpha(100);
                    String writeStr = "B";
                    writeCmd(writeStr.getBytes());
                }
                if(motionEvent.getAction() == MotionEvent.ACTION_UP)
                {
                    View v = findViewById(R.id.car_b);
                    v.getBackground().setAlpha(255);
                    String writeStr = "S";
                    writeCmd(writeStr.getBytes());
                }
                return false;
            }

        });
    }

    private void sendL1() {
        findViewById(R.id.car_l).setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent)
            {   //触摸，按住发送F,松开发送S
                if(motionEvent.getAction() == MotionEvent.ACTION_DOWN)
                {
                    View v = findViewById(R.id.car_l);
                    v.getBackground().setAlpha(100);
                    String writeStr = "L";
                    writeCmd(writeStr.getBytes());
                }
                if(motionEvent.getAction() == MotionEvent.ACTION_UP)
                {
                    View v = findViewById(R.id.car_l);
                    v.getBackground().setAlpha(255);
                    String writeStr = "S";
                    writeCmd(writeStr.getBytes());
                }
                return false;
            }

        });
    }

    private void sendR1() {
        findViewById(R.id.car_r).setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent)
            {   //触摸，按住发送F,松开发送S
                if(motionEvent.getAction() == MotionEvent.ACTION_DOWN)
                {
                    View v = findViewById(R.id.car_r);
                    v.getBackground().setAlpha(100);
                    String writeStr = "R";
                    writeCmd(writeStr.getBytes());
                }
                if(motionEvent.getAction() == MotionEvent.ACTION_UP)
                {
                    View v = findViewById(R.id.car_r);
                    v.getBackground().setAlpha(255);
                    String writeStr = "S";
                    writeCmd(writeStr.getBytes());
                }
                return false;
            }

        });
    }

    private void speed_add() {
        findViewById(R.id.speed_add).setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent)
            {
                if(motionEvent.getAction() == MotionEvent.ACTION_DOWN)
                {
                    mode = 7;
                    View v = findViewById(R.id.speed_add);
                    v.getBackground().setAlpha(100);
                    String writeStr = "Z";
                    writeCmd(writeStr.getBytes());
                }
                if(motionEvent.getAction() == MotionEvent.ACTION_UP)
                {
                    View v = findViewById(R.id.speed_add);
                    v.getBackground().setAlpha(255);
                    String writeStr = "S";
                    writeCmd(writeStr.getBytes());
                    mode = 0;
                }
                return false;
            }

        });
    }
    private void speed_sub() {
        findViewById(R.id.speed_sub).setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent)
            {
                if(motionEvent.getAction() == MotionEvent.ACTION_DOWN)
                {
                    mode = 7;
                    View v = findViewById(R.id.speed_sub);
                    v.getBackground().setAlpha(100);
                    String writeStr = "X";
                    writeCmd(writeStr.getBytes());
                }
                if(motionEvent.getAction() == MotionEvent.ACTION_UP)
                {
                    View v = findViewById(R.id.speed_sub);
                    v.getBackground().setAlpha(255);
                    String writeStr = "S";
                    writeCmd(writeStr.getBytes());
                    mode = 0;
                }
                return false;
            }

        });
    }

    //避障小车
    private void avoid_car() {
        Button car_avoid = findViewById(R.id.avoid_mode);
        car_avoid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                flag3 += 1;
                if (flag3 == 1) {
                    v.getBackground().setAlpha(100);
                    String writeStr = "h";
                    writeCmd(writeStr.getBytes());
                }
                if (flag3 > 1) {
                    v.getBackground().setAlpha(255);
                    String writeStr = "S";
                    writeCmd(writeStr.getBytes());
                    flag3 = 0;
                }
            }
        });
    }

    //跟随小车
    private void follow_car() {
        Button car_follow = findViewById(R.id.follow_mode);
        car_follow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                flag1 += 1;
                if (flag1 == 1) {
                    v.getBackground().setAlpha(100);
                    String writeStr = "i";
                    writeCmd(writeStr.getBytes());
                }
                if (flag1 > 1) {
                    v.getBackground().setAlpha(255);
                    String writeStr = "S";
                    writeCmd(writeStr.getBytes());
                    flag1 = 0;
                }
            }
        });
    }

    //寻迹小车
    private void track_car() {
        Button car_track = findViewById(R.id.track_mode);
        car_track.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                flag2 += 1;
                if (flag2 == 1) {
                    v.getBackground().setAlpha(100);
                    String writeStr = "j";
                    writeCmd(writeStr.getBytes());
                }
                if (flag2 > 1) {
                    v.getBackground().setAlpha(255);
                    String writeStr = "S";
                    writeCmd(writeStr.getBytes());
                    flag2 = 0;
                }
            }
        });
    }





    private void send_red() {
        findViewById(R.id.rgb_red).setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent)
            {
                if(motionEvent.getAction() == MotionEvent.ACTION_DOWN)
                {
                    View v = findViewById(R.id.rgb_red);
                    v.getBackground().setAlpha(100);

                }
                if(motionEvent.getAction() == MotionEvent.ACTION_UP)
                {
                    View v = findViewById(R.id.rgb_red);
                    v.getBackground().setAlpha(255);
                    String writeStr = "a";
                    writeCmd(writeStr.getBytes());
                }
                return false;
            }

        });
    }

    private void send_orange() {
        findViewById(R.id.rgb_orange).setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent)
            {
                if(motionEvent.getAction() == MotionEvent.ACTION_DOWN)
                {
                    View v = findViewById(R.id.rgb_orange);
                    v.getBackground().setAlpha(100);
                }
                if(motionEvent.getAction() == MotionEvent.ACTION_UP)
                {
                    View v = findViewById(R.id.rgb_orange);
                    v.getBackground().setAlpha(255);
                    String writeStr = "b";
                    writeCmd(writeStr.getBytes());
                }
                return false;
            }

        });
    }

    private void send_yellow() {
        findViewById(R.id.rgb_yellow).setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent)
            {
                if(motionEvent.getAction() == MotionEvent.ACTION_DOWN)
                {
                    View v = findViewById(R.id.rgb_yellow);
                    v.getBackground().setAlpha(100);
                }
                if(motionEvent.getAction() == MotionEvent.ACTION_UP)
                {
                    View v = findViewById(R.id.rgb_yellow);
                    v.getBackground().setAlpha(255);
                    String writeStr = "c";
                    writeCmd(writeStr.getBytes());
                }
                return false;
            }

        });
    }

    private void send_green() {
        findViewById(R.id.rgb_green).setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent)
            {
                if(motionEvent.getAction() == MotionEvent.ACTION_DOWN)
                {
                    View v = findViewById(R.id.rgb_green);
                    v.getBackground().setAlpha(100);
                }
                if(motionEvent.getAction() == MotionEvent.ACTION_UP)
                {
                    View v = findViewById(R.id.rgb_green);
                    v.getBackground().setAlpha(255);
                    String writeStr = "d";
                    writeCmd(writeStr.getBytes());
                }
                return false;
            }

        });
    }


    private void send_cyan() {
        findViewById(R.id.rgb_cyan).setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent)
            {
                if(motionEvent.getAction() == MotionEvent.ACTION_DOWN)
                {
                    View v = findViewById(R.id.rgb_cyan);
                    v.getBackground().setAlpha(100);
                }
                if(motionEvent.getAction() == MotionEvent.ACTION_UP)
                {
                    View v = findViewById(R.id.rgb_cyan);
                    v.getBackground().setAlpha(255);
                    String writeStr = "e";
                    writeCmd(writeStr.getBytes());
                }
                return false;
            }

        });
    }

    private void send_blue() {
        findViewById(R.id.rgb_blue).setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent)
            {
                if(motionEvent.getAction() == MotionEvent.ACTION_DOWN)
                {
                    View v = findViewById(R.id.rgb_blue);
                    v.getBackground().setAlpha(100);
                }
                if(motionEvent.getAction() == MotionEvent.ACTION_UP)
                {
                    View v = findViewById(R.id.rgb_blue);
                    v.getBackground().setAlpha(255);
                    String writeStr = "f";
                    writeCmd(writeStr.getBytes());
                }
                return false;
            }

        });
    }

    private void send_purple() {
        findViewById(R.id.rgb_purple).setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent)
            {
                if(motionEvent.getAction() == MotionEvent.ACTION_DOWN)
                {
                    View v = findViewById(R.id.rgb_purple);
                    v.getBackground().setAlpha(100);
                }
                if(motionEvent.getAction() == MotionEvent.ACTION_UP)
                {
                    View v = findViewById(R.id.rgb_purple);
                    v.getBackground().setAlpha(255);
                    String writeStr = "g";
                    writeCmd(writeStr.getBytes());
                }
                return false;
            }

        });
    }

    private void neo_add() {
        findViewById(R.id.neo_add).setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent)
            {
                if(motionEvent.getAction() == MotionEvent.ACTION_DOWN)
                {
                    View v = findViewById(R.id.neo_add);
                    v.getBackground().setAlpha(100);
                }
                if(motionEvent.getAction() == MotionEvent.ACTION_UP)
                {
                    View v = findViewById(R.id.neo_add);
                    v.getBackground().setAlpha(255);
                    String writeStr = "or";
                    writeCmd(writeStr.getBytes());
                }
                return false;
            }

        });
    }
    private void neo_sub() {
        findViewById(R.id.neo_sub).setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent)
            {
                if(motionEvent.getAction() == MotionEvent.ACTION_DOWN)
                {
                    View v = findViewById(R.id.neo_sub);
                    v.getBackground().setAlpha(100);
                }
                if(motionEvent.getAction() == MotionEvent.ACTION_UP)
                {
                    View v = findViewById(R.id.neo_sub);
                    v.getBackground().setAlpha(255);
                    String writeStr = "pr";
                    writeCmd(writeStr.getBytes());
                }
                return false;
            }

        });
    }

    private void neo_stop() {
        findViewById(R.id.neo_stop).setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent)
            {
                if(motionEvent.getAction() == MotionEvent.ACTION_DOWN)
                {
                    View v = findViewById(R.id.neo_stop);
                    v.getBackground().setAlpha(100);
                }
                if(motionEvent.getAction() == MotionEvent.ACTION_UP)
                {
                    View v = findViewById(R.id.neo_stop);
                    v.getBackground().setAlpha(255);
                    String writeStr = "qr";
                    writeCmd(writeStr.getBytes());
                }
                return false;
            }

        });
    }


    private void send_do() {
        findViewById(R.id.m_do2).setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent)
            {   //触摸，按住发送F,松开发送S
                if(motionEvent.getAction() == MotionEvent.ACTION_DOWN)
                {
                    View v = findViewById(R.id.m_do2);
                    v.getBackground().setAlpha(100);
                    String writeStr = "1";
                    writeCmd(writeStr.getBytes());
                }
                if(motionEvent.getAction() == MotionEvent.ACTION_UP)
                {
                    View v = findViewById(R.id.m_do2);
                    v.getBackground().setAlpha(255);
                    String writeStr = "0";
                    writeCmd(writeStr.getBytes());
                }
                return false;
            }

        });
    }

    private void send_re() {
        findViewById(R.id.m_re).setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent)
            {
                if(motionEvent.getAction() == MotionEvent.ACTION_DOWN)
                {
                    View v = findViewById(R.id.m_re);
                    v.getBackground().setAlpha(100);
                    String writeStr = "2";
                    writeCmd(writeStr.getBytes());
                }
                if(motionEvent.getAction() == MotionEvent.ACTION_UP)
                {
                    View v = findViewById(R.id.m_re);
                    v.getBackground().setAlpha(255);
                    String writeStr = "0";
                    writeCmd(writeStr.getBytes());
                }
                return false;
            }

        });
    }

    private void send_mi() {
        findViewById(R.id.m_mi).setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent)
            {
                if(motionEvent.getAction() == MotionEvent.ACTION_DOWN)
                {
                    View v = findViewById(R.id.m_mi);
                    v.getBackground().setAlpha(100);
                    String writeStr = "3";
                    writeCmd(writeStr.getBytes());
                }
                if(motionEvent.getAction() == MotionEvent.ACTION_UP)
                {
                    View v = findViewById(R.id.m_mi);
                    v.getBackground().setAlpha(255);
                    String writeStr = "0";
                    writeCmd(writeStr.getBytes());
                }
                return false;
            }

        });
    }

    private void send_fa() {
        findViewById(R.id.m_fa).setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent)
            {
                if(motionEvent.getAction() == MotionEvent.ACTION_DOWN)
                {
                    View v = findViewById(R.id.m_fa);
                    v.getBackground().setAlpha(100);
                    String writeStr = "4";
                    writeCmd(writeStr.getBytes());
                }
                if(motionEvent.getAction() == MotionEvent.ACTION_UP)
                {
                    View v = findViewById(R.id.m_fa);
                    v.getBackground().setAlpha(255);
                    String writeStr = "0";
                    writeCmd(writeStr.getBytes());
                }
                return false;
            }

        });
    }
    private void send_so() {
        findViewById(R.id.m_so).setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent)
            {
                if(motionEvent.getAction() == MotionEvent.ACTION_DOWN)
                {
                    View v = findViewById(R.id.m_so);
                    v.getBackground().setAlpha(100);
                    String writeStr = "5";
                    writeCmd(writeStr.getBytes());
                }
                if(motionEvent.getAction() == MotionEvent.ACTION_UP)
                {
                    View v = findViewById(R.id.m_so);
                    v.getBackground().setAlpha(255);
                    String writeStr = "0";
                    writeCmd(writeStr.getBytes());
                }
                return false;
            }

        });
    }

    private void send_la() {
        findViewById(R.id.m_la).setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent)
            {
                if(motionEvent.getAction() == MotionEvent.ACTION_DOWN)
                {
                    View v = findViewById(R.id.m_la);
                    v.getBackground().setAlpha(100);
                    String writeStr = "6";
                    writeCmd(writeStr.getBytes());
                }
                if(motionEvent.getAction() == MotionEvent.ACTION_UP)
                {
                    View v = findViewById(R.id.m_la);
                    v.getBackground().setAlpha(255);
                    String writeStr = "0";
                    writeCmd(writeStr.getBytes());
                }
                return false;
            }

        });
    }

    private void send_si() {
        findViewById(R.id.m_si).setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent)
            {
                if(motionEvent.getAction() == MotionEvent.ACTION_DOWN)
                {
                    View v = findViewById(R.id.m_si);
                    v.getBackground().setAlpha(100);
                    String writeStr = "7";
                    writeCmd(writeStr.getBytes());
                }
                if(motionEvent.getAction() == MotionEvent.ACTION_UP)
                {
                    View v = findViewById(R.id.m_si);
                    v.getBackground().setAlpha(255);
                    String writeStr = "0";
                    writeCmd(writeStr.getBytes());
                }
                return false;
            }

        });
    }

    int led_flag = 0;
    private void home_led() {
        Button car_avoid = findViewById(R.id.led_id);
        car_avoid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                led_flag += 1;
                if (led_flag == 1) {
                    v.getBackground().setAlpha(100);
                    String writeStr = "A";
                    writeCmd(writeStr.getBytes());
                }
                if (led_flag > 1) {
                    v.getBackground().setAlpha(255);
                    String writeStr = "H";
                    writeCmd(writeStr.getBytes());
                    led_flag = 0;
                }
            }
        });
    }

    int neo_flag = 0;
    private void home_neo() {
        Button car_avoid = findViewById(R.id.rgb_id);
        car_avoid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                neo_flag += 1;
                if (neo_flag == 1) {
                    v.getBackground().setAlpha(100);
                    String writeStr = "m";
                    writeCmd(writeStr.getBytes());
                }
                if (neo_flag > 1) {
                    v.getBackground().setAlpha(255);
                    String writeStr = "G";
                    writeCmd(writeStr.getBytes());
                    neo_flag = 0;
                }
            }
        });
    }

    int music_flag = 0;
    private void home_music() {
        Button car_avoid = findViewById(R.id.music_id);
        car_avoid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                music_flag += 1;
                if (music_flag == 1) {
                    v.getBackground().setAlpha(100);
                    String writeStr = "J";
                    writeCmd(writeStr.getBytes());
                }
                if (music_flag > 1) {
                    v.getBackground().setAlpha(255);
                    String writeStr = "I";
                    writeCmd(writeStr.getBytes());
                    music_flag = 0;
                }
            }
        });
    }



    int light_flag = 0;
    private void home_light() {
        Button car_avoid = findViewById(R.id.light_id);
        car_avoid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                light_flag += 1;
                if (light_flag == 1) {
                    mode = 1;  //为了刷新app界面来显示接收到的值
                    v.getBackground().setAlpha(100);
                    String writeStr = "y";
                    writeCmd(writeStr.getBytes());
                }
                if (light_flag > 1) {
                    v.getBackground().setAlpha(255);
                    String writeStr = "z";
                    writeCmd(writeStr.getBytes());
                    light_flag = 0;
                    mode = 0;
                }
            }
        });
    }

    int gas_flag = 0;
    private void home_gas() {
        Button car_avoid = findViewById(R.id.gas_id);
        car_avoid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gas_flag += 1;
                if (gas_flag == 1) {
                    mode = 2;
                    v.getBackground().setAlpha(100);
                    String writeStr = "k";
                    writeCmd(writeStr.getBytes());
                }
                if (gas_flag > 1) {
                    v.getBackground().setAlpha(255);
                    String writeStr = "z";
                    writeCmd(writeStr.getBytes());
                    gas_flag = 0;
                    mode = 0;
                }
            }
        });
    }

    int water_flag = 0;
    private void home_water() {
        Button car_avoid = findViewById(R.id.water_id);
        car_avoid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                water_flag += 1;
                if (water_flag == 1) {
                    mode = 3;
                    v.getBackground().setAlpha(100);
                    String writeStr = "t";
                    writeCmd(writeStr.getBytes());
                }
                if (water_flag > 1) {
                    v.getBackground().setAlpha(255);
                    String writeStr = "z";
                    writeCmd(writeStr.getBytes());
                   water_flag = 0;
                   mode = 0;
                }
            }
        });
    }

    int temp_flag = 0;
    private void home_temp() {
        Button car_avoid = findViewById(R.id.temp_id);
        car_avoid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                temp_flag += 1;
                if (temp_flag == 1) {
                    mode = 4;
                    v.getBackground().setAlpha(100);
                    String writeStr = "l";
                    writeCmd(writeStr.getBytes());
                }
                if (temp_flag > 1) {
                    v.getBackground().setAlpha(255);
                    String writeStr = "z";
                    writeCmd(writeStr.getBytes());
                    temp_flag = 0;
                    mode = 0;
                }
            }
        });
    }

    int humidity_flag = 0;
    private void home_humidity() {
        Button car_avoid = findViewById(R.id.humidity_id);
        car_avoid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                humidity_flag += 1;
                if (humidity_flag == 1) {
                    mode = 5;  //为了刷新app界面来显示接收到的值
                    v.getBackground().setAlpha(100);
                    String writeStr = "w";
                    writeCmd(writeStr.getBytes());
                }
                if (humidity_flag > 1) {
                    v.getBackground().setAlpha(255);
                    String writeStr = "z";
                    writeCmd(writeStr.getBytes());
                    humidity_flag = 0;
                    mode = 0;
                }
            }
        });
    }

    int body_flag = 0;
    private void home_body() {
        Button car_avoid = findViewById(R.id.body_id);
        car_avoid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                body_flag += 1;
                if (body_flag == 1) {
                    v.getBackground().setAlpha(100);
                    String writeStr = "*";
                    writeCmd(writeStr.getBytes());
                    mode = 6;
                }
                if (body_flag > 1) {
                    v.getBackground().setAlpha(255);
                    String writeStr = "z";
                    writeCmd(writeStr.getBytes());
                    body_flag = 0;
                    mode = 0;
                }
            }
        });
    }

    int door_flag = 0;
    private void home_door() {
        Button car_avoid = findViewById(R.id.door_id);
        car_avoid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                door_flag += 1;
                if (door_flag == 1) {
                    v.getBackground().setAlpha(100);
                    String writeStr = "W";
                    writeCmd(writeStr.getBytes());
                }
                if (door_flag > 1) {
                    v.getBackground().setAlpha(255);
                    String writeStr = "M";
                    writeCmd(writeStr.getBytes());
                    door_flag = 0;
                }
            }
        });
    }

    int window_flag = 0;
    private void home_window() {
        Button car_avoid = findViewById(R.id.window_id);
        car_avoid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                window_flag += 1;
                if (window_flag == 1) {
                    v.getBackground().setAlpha(100);
                    String writeStr = "U";
                    writeCmd(writeStr.getBytes());
                }
                if (window_flag > 1) {
                    v.getBackground().setAlpha(255);
                    String writeStr = "9";
                    writeCmd(writeStr.getBytes());
                    window_flag = 0;
                }
            }
        });
    }

    int servo3_flag = 0;
    private void home_servo3() {
        Button car_avoid = findViewById(R.id.servo3_id);
        car_avoid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                servo3_flag += 1;
                if (servo3_flag == 1) {
                    v.getBackground().setAlpha(100);
                    String writeStr = "P";
                    writeCmd(writeStr.getBytes());
                }
                if (servo3_flag > 1) {
                    v.getBackground().setAlpha(255);
                    String writeStr = "8";
                    writeCmd(writeStr.getBytes());
                    servo3_flag = 0;
                }
            }
        });
    }

    int red_flag = 0;
    private void home_red() {
        Button car_avoid = findViewById(R.id.rgb_r_id);
        car_avoid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                red_flag += 1;
                if (red_flag == 1) {
                    v.getBackground().setAlpha(100);
                    String writeStr = "V";
                    writeCmd(writeStr.getBytes());
                }
                if (red_flag > 1) {
                    v.getBackground().setAlpha(255);
                    String writeStr = "Y";
                    writeCmd(writeStr.getBytes());
                    red_flag = 0;
                }
            }
        });
    }

    int green_flag = 0;
    private void home_green() {
        Button car_avoid = findViewById(R.id.rgb_g_id);
        car_avoid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                green_flag += 1;
                if (green_flag == 1) {
                    v.getBackground().setAlpha(100);
                    String writeStr = "n";
                    writeCmd(writeStr.getBytes());
                }
                if (green_flag > 1) {
                    v.getBackground().setAlpha(255);
                    String writeStr = "Y";
                    writeCmd(writeStr.getBytes());
                    green_flag = 0;
                }
            }
        });
    }

    int blue_flag = 0;
    private void home_blue() {
        Button car_avoid = findViewById(R.id.rgb_b_id);
        car_avoid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                blue_flag += 1;
                if (blue_flag == 1) {
                    v.getBackground().setAlpha(100);
                    String writeStr = "Q";
                    writeCmd(writeStr.getBytes());
                }
                if (blue_flag > 1) {
                    v.getBackground().setAlpha(255);
                    String writeStr = "Y";
                    writeCmd(writeStr.getBytes());
                    blue_flag = 0;
                }
            }
        });
    }

    private void door_seek_val()
    {
        /**
         * 门的PWM控制,拖动条
         * SeekBar
         */
        door_value = (TextView)findViewById(R.id.door_value);
        door_bar = (SeekBar)findViewById(R.id.seekBar_door);

        door_bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                door_str = String.valueOf(progress);   //整型转字符串
                door_value.setText(door_str);   //这里显示的数据里是 整形时，不会报错，但会闪退，所以要先转为字符串
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                //Toast.makeText(mContext, "触碰SeekBar", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                //Toast.makeText(mContext, "放开SeekBar", Toast.LENGTH_SHORT).show();
                String writeStr = "u"+door_str+"#";
                writeCmd(writeStr.getBytes());
            }
        });
    }

    private void window_seek_val()
    {
        /**
         * 门的PWM控制,拖动条
         * SeekBar
         */
        window_value = (TextView)findViewById(R.id.window_value);
        win_bar = (SeekBar)findViewById(R.id.seekBar_window);

        win_bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                win_str = String.valueOf(progress);   //整型转字符串
                window_value.setText(win_str);   //这里显示的数据里是 整形时，不会报错，但会闪退，所以要先转为字符串
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                //Toast.makeText(mContext, "触碰SeekBar", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                //Toast.makeText(mContext, "放开SeekBar", Toast.LENGTH_SHORT).show();
                String writeStr = "v"+win_str+"#";
                writeCmd(writeStr.getBytes());
            }
        });
    }

    private void servo3_seek_val()
    {
        /**
         * 门的PWM控制,拖动条
         * SeekBar
         */
        servo3_value = (TextView)findViewById(R.id.servo3_val);
        servo3_bar = (SeekBar)findViewById(R.id.seekBar_servo3);

        servo3_bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                servo3_str = String.valueOf(progress);   //整型转字符串
                servo3_value.setText(servo3_str);   //这里显示的数据里是 整形时，不会报错，但会闪退，所以要先转为字符串
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                //Toast.makeText(mContext, "触碰SeekBar", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                //Toast.makeText(mContext, "放开SeekBar", Toast.LENGTH_SHORT).show();
                String writeStr = "s"+servo3_str+"#";
                writeCmd(writeStr.getBytes());
            }
        });
    }

    private void red_seek_val()
    {
        /**
         * 门的PWM控制,拖动条
         * SeekBar
         */
        red_value = (TextView)findViewById(R.id.red_value);
        red_bar = (SeekBar)findViewById(R.id.seekBar_red);

        red_bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                red_str = String.valueOf(progress);   //整型转字符串
                red_value.setText(red_str);   //这里显示的数据里是 整形时，不会报错，但会闪退，所以要先转为字符串
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                //Toast.makeText(mContext, "触碰SeekBar", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                //Toast.makeText(mContext, "放开SeekBar", Toast.LENGTH_SHORT).show();
                String writeStr = "x"+red_str+"#";
                writeCmd(writeStr.getBytes());
            }
        });
    }

    private void green_seek_val()
    {
        /**
         * 门的PWM控制,拖动条
         * SeekBar
         */
        green_value = (TextView)findViewById(R.id.green_value);
        green_bar = (SeekBar)findViewById(R.id.seekBar_green);

        green_bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                green_str = String.valueOf(progress);   //整型转字符串
                green_value.setText(green_str);   //这里显示的数据里是 整形时，不会报错，但会闪退，所以要先转为字符串
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                //Toast.makeText(mContext, "触碰SeekBar", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                //Toast.makeText(mContext, "放开SeekBar", Toast.LENGTH_SHORT).show();
                String writeStr = "D"+green_str+"#";
                writeCmd(writeStr.getBytes());
            }
        });
    }

    private void blue_seek_val()
    {
        /**
         * 门的PWM控制,拖动条
         * SeekBar
         */
        blue_value = (TextView)findViewById(R.id.blue_value);
        blue_bar = (SeekBar)findViewById(R.id.seekBar_blue);

        blue_bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                blue_str = String.valueOf(progress);   //整型转字符串
                blue_value.setText(blue_str);   //这里显示的数据里是 整形时，不会报错，但会闪退，所以要先转为字符串
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                //Toast.makeText(mContext, "触碰SeekBar", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                //Toast.makeText(mContext, "放开SeekBar", Toast.LENGTH_SHORT).show();
                String writeStr = "E"+blue_str+"#";
                writeCmd(writeStr.getBytes());
            }
        });
    }
}





