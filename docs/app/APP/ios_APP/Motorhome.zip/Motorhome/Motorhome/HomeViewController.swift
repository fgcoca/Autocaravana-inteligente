//
//  HomeViewController.swift
//  Motorhome
//
//  Created by lisagu on 2021/1/7.
//  Copyright © 2021 xiuxian. All rights reserved.
//

import UIKit
import CoreBluetooth   //申明蓝牙库文件

class HomeViewController: UIViewController , UITextFieldDelegate, BluetoothSerialDelegate {
    
    @IBOutlet weak var light_outle: UIButton!
    @IBOutlet weak var gas_outle: UIButton!
    @IBOutlet weak var water_outle: UIButton!
    @IBOutlet weak var temp_outle: UIButton!
    @IBOutlet weak var humidity_outle: UIButton!
    
    @IBOutlet weak var led_outle: UIButton!
    @IBOutlet weak var ws2812_outle: UIButton!
    @IBOutlet weak var buzzer_outle: UIButton!
    
    @IBOutlet weak var R_slider: UISlider!
    
    @IBOutlet weak var G_slider: UISlider!
    @IBOutlet weak var G_text: UILabel!
    
    @IBOutlet weak var B_slider: UISlider!
    
    @IBOutlet weak var B_text: UILabel!
    
    @IBOutlet weak var body_outle: UIButton!
    @IBOutlet weak var body_text: UILabel!
    
    
    
    //继承蓝牙连接
    func serialDidChangeState() {
        //reloadView()
        // dismissKeyboard()  //这个方法是取消第一响应者状态的
        let hud = MBProgressHUD.showAdded(to: view, animated: true)
        hud?.mode = MBProgressHUDMode.text
        hud?.labelText = "Disconnected"   //屏幕中显示  Disconnected
        hud?.hide(true, afterDelay: 1.0)   //显示1.0秒后隐藏
    }
    
    func serialDidDisconnect(_ peripheral: CBPeripheral, error: NSError?) {
        // reloadView()
        if serial.centralManager.state != .poweredOn {  //蓝牙被关闭
            //dismissKeyboard()  //这个方法是取消第一响应者状态的
            let hud = MBProgressHUD.showAdded(to: view, animated: true)
            hud?.mode = MBProgressHUDMode.text
            hud?.labelText = "Bluetooth turned off"   //屏幕中显示  Bluetooth turned off
            hud?.hide(true, afterDelay: 1.0)
        }
    }
    
    
    @IBOutlet weak var light_sensor2: UILabel!
    @IBOutlet weak var gas_sensor: UILabel!
    @IBOutlet weak var water_sensor: UILabel!
    @IBOutlet weak var temp_sensor: UILabel!
    @IBOutlet weak var humidity_sensor: UILabel!
    
    
    
    
    //文本输入
    @IBOutlet weak var input_text: UITextField!
    
    //Slider
    @IBOutlet weak var door_slider: UISlider!
    @IBOutlet weak var door_text: UILabel!
    
    @IBOutlet weak var window_slider: UISlider!
    @IBOutlet weak var window_text: UILabel!
    
    @IBOutlet weak var led2_slider: UISlider!
    @IBOutlet weak var led2_text: UILabel!
    
    @IBOutlet weak var fans_text: UILabel!
    
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        ///////////door_slider//////
        door_slider.minimumValue = 0
        door_slider.maximumValue = 180
        door_slider.setValue(0, animated: true)
        door_slider.isContinuous = false  //滑动停止之后才改变数据
        door_slider.addTarget(self, action: #selector(getter: HomeViewController.door_slider), for: UIControl.Event.valueChanged)
        
        //////////window_slider//////
        window_slider.minimumValue = 0
        window_slider.maximumValue = 180
        window_slider.setValue(0, animated: true)
        window_slider.isContinuous = false
        window_slider.addTarget(self, action: #selector(getter: HomeViewController.window_slider), for: UIControl.Event.valueChanged)
       
        
        /////////led2_slider//////////
        led2_slider.minimumValue = 0
        led2_slider.maximumValue = 180
        led2_slider.setValue(0, animated: true)
        led2_slider.isContinuous = false
        led2_slider.addTarget(self, action: #selector(getter: HomeViewController.led2_slider), for: UIControl.Event.valueChanged)
        
        ///////////fans_slider/////////
        R_slider.minimumValue = 0
        R_slider.maximumValue = 255
        R_slider.setValue(0, animated: true)
        R_slider.isContinuous = false
        R_slider.addTarget(self, action: #selector(getter: HomeViewController.R_slider), for: UIControl.Event.valueChanged)
        
        G_slider.minimumValue = 0
        G_slider.maximumValue = 255
        G_slider.setValue(0, animated: true)
        G_slider.isContinuous = false
        G_slider.addTarget(self, action: #selector(getter: HomeViewController.G_slider), for: UIControl.Event.valueChanged)
        
        B_slider.minimumValue = 0
        B_slider.maximumValue = 255
        B_slider.setValue(0, animated: true)
        B_slider.isContinuous = false
        B_slider.addTarget(self, action: #selector(getter: HomeViewController.B_slider), for: UIControl.Event.valueChanged)
        
        
        reloadView()  //刷新，不然文本显示不出接收到的数据

        // Do any additional setup after loading the view.
        NotificationCenter.default.addObserver(self, selector: #selector(HomeViewController.reloadView), name: NSNotification.Name(rawValue: "reloadStartViewController"), object: nil)
    }
    
    //刷新界面
    @objc func reloadView() {
        // in case we're the visible view again；
        serial.delegate = self
    }
    

    //////////点灯//////////
    var led_flag = 0
    @IBAction func led1_button(_ sender: UIButton) {
        led_flag = led_flag + 1
        if led_flag == 1
        {
            serial.sendMessageToDevice("A")
            led_outle.backgroundColor = UIColor.init(white: 0.5, alpha: 0.5)
        }
        if led_flag > 1
        {
            serial.sendMessageToDevice("H")
            led_outle.backgroundColor = UIColor.init(white: 1, alpha: 0)
            led_flag = 0
        }
    }
    
    
    var relay_flag = 0
    @IBAction func relay1(_ sender: UIButton) {
        relay_flag = relay_flag + 1
        if relay_flag == 1
        {
            serial.sendMessageToDevice("m")
            ws2812_outle.backgroundColor = UIColor.init(white: 0.5, alpha: 0.5)
        }
        if relay_flag > 1
        {
            serial.sendMessageToDevice("G")
            ws2812_outle.backgroundColor = UIColor.init(white: 1, alpha: 0)
            relay_flag = 0
        }
    }
    
    //////////////music///////////////
    var buzzer_flag = 0
    @IBAction func music(_ sender: UIButton) {
        buzzer_flag = buzzer_flag + 1
        if buzzer_flag == 1
        {
            serial.sendMessageToDevice("J")
            buzzer_outle.backgroundColor = UIColor.init(white: 0.5, alpha: 0.5)
        }
        if buzzer_flag > 1
        {
            serial.sendMessageToDevice("I")
            buzzer_outle.backgroundColor = UIColor.init(white: 1, alpha: 0)
            buzzer_flag = 0
        }
    }
    
    
    //////////door
    var door_flag = 0
    @IBAction func door1(_ sender: UIButton) {
        door_flag = door_flag + 1
        if door_flag == 1
        {
            serial.sendMessageToDevice("W")
        }
        if door_flag > 1
        {
            serial.sendMessageToDevice("M")
            door_flag = 0
        }
    }
    
    var window_flag = 0
    @IBAction func window1(_ sender: UIButton) {
        window_flag = window_flag + 1
        if window_flag == 1
        {
            serial.sendMessageToDevice("U")
        }
        if window_flag > 1
        {
            serial.sendMessageToDevice("9")
            window_flag = 0
        }
    }
    
    var led2_flag = 0
    @IBAction func led222(_ sender: UIButton) {
        led2_flag = led2_flag + 1
        if led2_flag == 1
        {
            serial.sendMessageToDevice("P")
        }
        if led2_flag > 1
        {
            serial.sendMessageToDevice("8")
            led2_flag = 0
        }
    }
    
    var R_flag = 0
    @IBAction func fans111(_ sender: UIButton) {
        R_flag = R_flag + 1
        if R_flag == 1
        {
            serial.sendMessageToDevice("V")
        }
        if R_flag > 1
        {
            serial.sendMessageToDevice("Y")
            R_flag = 0
        }
    }
    
    var G_flag = 0
    @IBAction func G_click(_ sender: UIButton) {
        G_flag = G_flag + 1
        if G_flag == 1
        {
            serial.sendMessageToDevice("n")
        }
        if G_flag > 1
        {
            serial.sendMessageToDevice("Y")
            G_flag = 0
        }
    }
    
    var B_flag = 0
    @IBAction func B_click(_ sender: UIButton) {
        B_flag = B_flag + 1
        if B_flag == 1
        {
            serial.sendMessageToDevice("Q")
        }
        if B_flag > 1
        {
            serial.sendMessageToDevice("Y")
            B_flag = 0
        }
    }
    
    ////////door_slider//////////
    @IBAction func door(_ sender: UISlider) {
        var door_ser = Int(door_slider.value) //浮点数转整形
        var door_value = String(door_ser) //整形转为字符串
        door_text.text = door_value
        serial.sendMessageToDevice("u")
        serial.sendMessageToDevice(door_value)
        serial.sendMessageToDevice("#")
    }
    
    ///////window_slider//////////
    @IBAction func window(_ sender: UISlider) {
        var window_ser = Int(window_slider.value)
        var window_value = String(window_ser)
        window_text.text = window_value
        serial.sendMessageToDevice("v")
        serial.sendMessageToDevice(window_value)
        serial.sendMessageToDevice("#")
    }
    
    /////////led2_slider////////
    @IBAction func led2(_ sender: UISlider) {
        var led2_ser = Int(led2_slider.value)
        var led2_value = String(led2_ser)
        led2_text.text = led2_value
        serial.sendMessageToDevice("s")
        serial.sendMessageToDevice(led2_value)
        serial.sendMessageToDevice("#")
    }
    
    ////////////fans_slider////////
    @IBAction func fans(_ sender: UISlider) {
        var fans_ser = Int(R_slider.value)
        var fans_value = String(fans_ser)
        fans_text.text = fans_value
        serial.sendMessageToDevice("x")
        serial.sendMessageToDevice(fans_value)
        serial.sendMessageToDevice("#")
    }
    
    @IBAction func G_siler_change(_ sender: UISlider) {
        var G_val = Int(G_slider.value)
        var G_value = String(G_val)
        G_text.text = G_value
        serial.sendMessageToDevice("D")
        serial.sendMessageToDevice(G_value)
        serial.sendMessageToDevice("#")
    }
    
    @IBAction func B_Slider_change(_ sender: UISlider) {
        var B_val = Int(B_slider.value)
        var B_value = String(B_val)
        B_text.text = B_value
        serial.sendMessageToDevice("E")
        serial.sendMessageToDevice(B_value)
        serial.sendMessageToDevice("#")
    }
    
    //点击光敏，获取值
    var i = 0
    var j = 0
    var k = 0
    var l = 0
    var m = 0
    var n = 0
    
    //光敏
    @IBAction func light_ck(_ sender: UIButton) {
        
        j = 0
        k = 0
        l = 0
        m = 0
        n = 0
        i = i + 1
        if (i == 1)
        {
            serial.sendMessageToDevice("y")
            light_outle.backgroundColor = UIColor.init(white: 0.5, alpha: 0.5)
//            gas_outle.isEnabled = false
//            water_outle.isEnabled = false
//            temp_outle.isEnabled = false
//            humidity_outle.isEnabled = false
        }
        else
        {
            serial.sendMessageToDevice("z")
            light_outle.backgroundColor = UIColor.init(white: 1, alpha: 0)
//            gas_outle.isEnabled = true
//            water_outle.isEnabled = true
//            temp_outle.isEnabled = true
//            humidity_outle.isEnabled = true
            i = 0
        }
    }
    
    //气体按钮
    
    @IBAction func gas_click(_ sender: UIButton) {
        i = 0
        k = 0
        l = 0
        m = 0
        n = 0
        j = j + 1
        
        if (j == 1)
        {
            serial.sendMessageToDevice("k")
            gas_outle.backgroundColor = UIColor.init(white: 0.5, alpha: 0.5)
//            light_outle.isEnabled = false
//            water_outle.isEnabled = false
//            temp_outle.isEnabled = false
//            humidity_outle.isEnabled = false
        }
        else
        {
            serial.sendMessageToDevice("z")
            gas_outle.backgroundColor = UIColor.init(white: 1, alpha: 0)
//            light_outle.isEnabled = true
//            water_outle.isEnabled = true
//            temp_outle.isEnabled = true
//            humidity_outle.isEnabled = true
            j = 0
        }
    }
    
    @IBAction func water_ck(_ sender: UIButton) {
        i = 0
        k = 0
        j = 0
        m = 0
        n = 0
        l = l + 1
        
        if (l == 1)
        {
            serial.sendMessageToDevice("t")
            water_outle.backgroundColor = UIColor.init(white: 0.5, alpha: 0.5)
//            light_outle.isEnabled = false
//            gas_outle.isEnabled = false
//            temp_outle.isEnabled = false
//            humidity_outle.isEnabled = false
        }
        else
        {
            serial.sendMessageToDevice("z")
            water_outle.backgroundColor = UIColor.init(white: 1, alpha: 0)
//            light_outle.isEnabled = true
//            gas_outle.isEnabled = true
//            temp_outle.isEnabled = true
//            humidity_outle.isEnabled = true
            l = 0
        }
    }
    

    
    //温度
    @IBAction func soil_click(_ sender: UIButton) {
        i = 0
        j = 0
        l = 0
        m = 0
        n = 0
        k = k + 1
        if (k == 1)
        {
            serial.sendMessageToDevice("l")
            temp_outle.backgroundColor = UIColor.init(white: 0.5, alpha: 0.5)
//            gas_outle.isEnabled = false
//            water_outle.isEnabled = false
//            light_outle.isEnabled = false
//            humidity_outle.isEnabled = false
        }
        else
        {
            serial.sendMessageToDevice("z")
            temp_outle.backgroundColor = UIColor.init(white: 1, alpha: 0)
//            gas_outle.isEnabled = true
//            water_outle.isEnabled = true
//            light_outle.isEnabled = true
//            humidity_outle.isEnabled = true
            k = 0
        }
    }
    
    //DHT11 湿度传感器
    @IBAction func H_click(_ sender: UIButton) {
        i = 0
        j = 0
        k = 0
        l = 0
        n = 0
        m = m + 1
        if (m == 1)
        {
            serial.sendMessageToDevice("w")
            humidity_outle.backgroundColor = UIColor.init(white: 0.5, alpha: 0.5)
//            gas_outle.isEnabled = false
//            water_outle.isEnabled = false
//            temp_outle.isEnabled = false
//            light_outle.isEnabled = false
        }
        else
        {
            serial.sendMessageToDevice("z")
            humidity_outle.backgroundColor = UIColor.init(white: 1, alpha: 0)
//            gas_outle.isEnabled = true
//            water_outle.isEnabled = true
//            temp_outle.isEnabled = true
//            light_outle.isEnabled = true
            m = 0
        }
    }
    
    //是否有人
    @IBAction func somebody(_ sender: UIButton) {
        i = 0
        j = 0
        k = 0
        l = 0
        m = 0
        n = n + 1
        if (n == 1)
        {
            serial.sendMessageToDevice("*")
            body_outle.backgroundColor = UIColor.init(white: 0.5, alpha: 0.5)
//            gas_outle.isEnabled = false
//            water_outle.isEnabled = false
//            temp_outle.isEnabled = false
//            light_outle.isEnabled = false
        }
        else
        {
            serial.sendMessageToDevice("z")
            body_outle.backgroundColor = UIColor.init(white: 1, alpha: 0)
//            gas_outle.isEnabled = true
//            water_outle.isEnabled = true
//            temp_outle.isEnabled = true
//            light_outle.isEnabled = true
            n = 0
        }
    }
    

    
    /*func textViewScrollToBottom() {
        //let range = NSMakeRange(NSString(string: mainTextView.text).length - 1, 1)
        //mainTextView.scrollRangeToVisible(range)
        let range = NSMakeRange(NSString(string: light_sensor2.text).length - 1, 1)
        light_sensor2.scrollRangeToVisible(range)
    }*/
    
    
    //MARK: BluetoothSerialDelegate
    
    func serialDidReceiveString(_ message: String) {
        // add the received text to the textView, optionally with a line break at the end；/将接收到的文本添加到文本视图中，可以选择在末尾加一个换行符
        if message == "Danger"
        {
            gas_sensor.text = message
            light_sensor2.isEnabled = false
            temp_sensor.isEnabled = false
            water_sensor.isEnabled = false
            humidity_sensor.isEnabled = false
            body_text.isEnabled = false
        }
        
        //if message == "Water"
        //{
        //water.text = message
        //}
        
        if(i == 1)
        {
            light_sensor2.text = message
            gas_sensor.isEnabled = false
            temp_sensor.isEnabled = false
            water_sensor.isEnabled = false
            humidity_sensor.isEnabled = false
            body_text.isEnabled = false
        }
        
        if j == 1
        {
            gas_sensor.text = message
            light_sensor2.isEnabled = false
            temp_sensor.isEnabled = false
            water_sensor.isEnabled = false
            humidity_sensor.isEnabled = false
            body_text.isEnabled = false
        }
        
        if (k == 1)
        {
            temp_sensor.text = message
            light_sensor2.isEnabled = false
            gas_sensor.isEnabled = false
            water_sensor.isEnabled = false
            humidity_sensor.isEnabled = false
            body_text.isEnabled = false
        }
        
        if ((l == 1) || (message == "Water"))
        {
            water_sensor.text = message
            light_sensor2.isEnabled = false
            gas_sensor.isEnabled = false
            temp_sensor.isEnabled = false
            humidity_sensor.isEnabled = false
            body_text.isEnabled = false
        }
        if (m == 1)
        {
            humidity_sensor.text = message
            light_sensor2.isEnabled = false
            gas_sensor.isEnabled = false
            water_sensor.isEnabled = false
            temp_sensor.isEnabled = false
            body_text.isEnabled = false
        }
        if (n == 1)
        {
            body_text.text = message
            light_sensor2.isEnabled = false
            gas_sensor.isEnabled = false
            water_sensor.isEnabled = false
            temp_sensor.isEnabled = false
            humidity_sensor.isEnabled = false
        }
    }

}
