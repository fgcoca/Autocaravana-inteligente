//
//  BuzzerViewController.swift
//  Motorhome
//
//  Created by lisagu on 2021/1/19.
//  Copyright © 2021 xiuxian. All rights reserved.
//

import UIKit
import CoreBluetooth   //申明蓝牙库文件

class BuzzerViewController: UIViewController, UITextFieldDelegate, BluetoothSerialDelegate {
    
    func serialDidChangeState() {
        //reloadView()
        // dismissKeyboard()  //这个方法是取消第一响应者状态的
        let hud = MBProgressHUD.showAdded(to: view, animated: true)
        hud?.mode = MBProgressHUDMode.text
        hud?.labelText = "Disconnected"   //屏幕中显示  Disconnected
        hud?.hide(true, afterDelay: 1.0)   //显示1.0秒后隐藏
    }
    
    func serialDidDisconnect(_ peripheral: CBPeripheral, error: NSError?) {
        // reloadView()
        if serial.centralManager.state != .poweredOn {  //蓝牙被关闭
            //dismissKeyboard()  //这个方法是取消第一响应者状态的
            let hud = MBProgressHUD.showAdded(to: view, animated: true)
            hud?.mode = MBProgressHUDMode.text
            hud?.labelText = "Bluetooth turned off"   //屏幕中显示  Bluetooth turned off
            hud?.hide(true, afterDelay: 1.0)
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func do_down(_ sender: UIButton) {
        serial.sendMessageToDevice("1")
    }
    @IBAction func do_up(_ sender: UIButton) {
        serial.sendMessageToDevice("0")
    }
    @IBAction func re_down(_ sender: UIButton) {
        serial.sendMessageToDevice("2")
    }
    @IBAction func re_up(_ sender: UIButton) {
        serial.sendMessageToDevice("0")
    }
    @IBAction func mi_down(_ sender: UIButton) {
        serial.sendMessageToDevice("3")
    }
    @IBAction func mi_up(_ sender: UIButton) {
        serial.sendMessageToDevice("0")
    }
    @IBAction func fa_down(_ sender: UIButton) {
        serial.sendMessageToDevice("4")
    }
    @IBAction func fa_up(_ sender: UIButton) {
        serial.sendMessageToDevice("0")
    }
    @IBAction func so_down(_ sender: UIButton) {
        serial.sendMessageToDevice("5")
    }
    @IBAction func so_up(_ sender: UIButton) {
        serial.sendMessageToDevice("0")
    }
    @IBAction func la_down(_ sender: UIButton) {
        serial.sendMessageToDevice("6")
    }
    @IBAction func la_up(_ sender: UIButton) {
        serial.sendMessageToDevice("0")
    }
    @IBAction func si_down(_ sender: UIButton) {
        serial.sendMessageToDevice("7")
    }
    @IBAction func si_up(_ sender: UIButton) {
        serial.sendMessageToDevice("0")
    }

}
