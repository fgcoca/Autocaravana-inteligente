//
//  GameViewController.swift
//  Motorhome
//
//  Created by lisagu on 2021/1/7.
//  Copyright © 2021 xiuxian. All rights reserved.
//

import UIKit
import CoreBluetooth   //申明蓝牙库文件

class GameViewController: UIViewController, BluetoothSerialDelegate  {
    @IBOutlet weak var car_mode: UIView!
    @IBOutlet weak var car_RGB: UIView!
    @IBOutlet weak var car_neo: UIView!
    @IBOutlet weak var car_buzzer: UIView!
    @IBOutlet weak var speed_text: UILabel!
    
    
    
    func serialDidChangeState() {
        //reloadView()
        // dismissKeyboard()  //这个方法是取消第一响应者状态的
        let hud = MBProgressHUD.showAdded(to: view, animated: true)
        hud?.mode = MBProgressHUDMode.text
        hud?.labelText = "Disconnected"   //屏幕中显示  Disconnected
        hud?.hide(true, afterDelay: 1.0)   //显示1.0秒后隐藏
    }
    
    func serialDidDisconnect(_ peripheral: CBPeripheral, error: NSError?) {
        // reloadView()
        if serial.centralManager.state != .poweredOn {  //蓝牙被关闭
            //dismissKeyboard()  //这个方法是取消第一响应者状态的
            let hud = MBProgressHUD.showAdded(to: view, animated: true)
            hud?.mode = MBProgressHUDMode.text
            hud?.labelText = "Bluetooth turned off"   //屏幕中显示  Bluetooth turned off
            hud?.hide(true, afterDelay: 1.0)
        }
    }


    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        reloadView()
    }
    
    //刷新界面
    @objc func reloadView() {
        // in case we're the visible view again；
        serial.delegate = self
    }
    
    @IBAction func Car_Mode(_ sender: UIButton) {
        car_mode.isHidden = false
        car_RGB.isHidden = true
        car_neo.isHidden = true
        car_buzzer.isHidden = true
    }
    @IBAction func Car_RGB(_ sender: UIButton) {
        car_mode.isHidden = true
        car_RGB.isHidden = false
        car_neo.isHidden = true
        car_buzzer.isHidden = true
    }
    @IBAction func Car_Neo(_ sender: UIButton) {
        car_mode.isHidden = true
        car_RGB.isHidden = true
        car_neo.isHidden = false
        car_buzzer.isHidden = true
    }
    @IBAction func Car_Buzzer(_ sender: UIButton) {
        car_mode.isHidden = true
        car_RGB.isHidden = true
        car_neo.isHidden = true
        car_buzzer.isHidden = false
    }
    
    
    
    @IBAction func car_F_down(_ sender: UIButton) {
        serial.sendMessageToDevice("F")
    }
    @IBAction func car_F_up(_ sender: UIButton) {
        serial.sendMessageToDevice("S")
    }
    @IBAction func car_L_down(_ sender: UIButton) {
        serial.sendMessageToDevice("L")
    }
    @IBAction func car_L_up(_ sender: UIButton) {
        serial.sendMessageToDevice("S")
    }
    @IBAction func car_R_down(_ sender: UIButton) {
        serial.sendMessageToDevice("R")
    }
    @IBAction func car_R_up(_ sender: UIButton) {
        serial.sendMessageToDevice("S")
    }
    @IBAction func car_B_down(_ sender: UIButton) {
        serial.sendMessageToDevice("B")
    }
    @IBAction func car_B_up(_ sender: UIButton) {
        serial.sendMessageToDevice("S")
    }
    var speed_flag = 0
    @IBAction func car_add_down(_ sender: UIButton) {
        serial.sendMessageToDevice("Z")
        speed_flag = 1
    }
    @IBAction func car_add_up(_ sender: UIButton) {
        serial.sendMessageToDevice("S")
        speed_flag = 0
    }
    @IBAction func car_sub_down(_ sender: UIButton) {
        serial.sendMessageToDevice("X")
        speed_flag = 2
    }
    @IBAction func car_sub_up(_ sender: UIButton) {
        serial.sendMessageToDevice("S")
        speed_flag = 0
    }
    
    //接收数据
    func serialDidReceiveString(_ message: String) {
        // add the received text to the textView, optionally with a line break at the end；/将接收到的文本添加到文本视图中，可以选择在末尾加一个换行符
        if speed_flag == 1
        {
            speed_text.text = message
        }
        if speed_flag == 2
        {
            speed_text.text = message
        }
    }
    
    
}
