//
//  ModeViewController.swift
//  Motorhome
//
//  Created by lisagu on 2021/1/19.
//  Copyright © 2021 xiuxian. All rights reserved.
//

import UIKit
import CoreBluetooth   //申明蓝牙库文件

class ModeViewController: UIViewController, UITextFieldDelegate, BluetoothSerialDelegate {
    
    @IBOutlet weak var avoid_car_outle: UIButton!
    @IBOutlet weak var follow_car_outle: UIButton!
    @IBOutlet weak var track_car_outle: UIButton!
    
    func serialDidChangeState() {
        //reloadView()
        // dismissKeyboard()  //这个方法是取消第一响应者状态的
        let hud = MBProgressHUD.showAdded(to: view, animated: true)
        hud?.mode = MBProgressHUDMode.text
        hud?.labelText = "Disconnected"   //屏幕中显示  Disconnected
        hud?.hide(true, afterDelay: 1.0)   //显示1.0秒后隐藏
    }
    
    func serialDidDisconnect(_ peripheral: CBPeripheral, error: NSError?) {
        // reloadView()
        if serial.centralManager.state != .poweredOn {  //蓝牙被关闭
            //dismissKeyboard()  //这个方法是取消第一响应者状态的
            let hud = MBProgressHUD.showAdded(to: view, animated: true)
            hud?.mode = MBProgressHUDMode.text
            hud?.labelText = "Bluetooth turned off"   //屏幕中显示  Bluetooth turned off
            hud?.hide(true, afterDelay: 1.0)
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    //功能
    //避障小车
    var avoid_flag = 0
    @IBAction func avoid_car(_ sender: UIButton) {
        avoid_flag += 1
        if(avoid_flag == 1)
        {
            serial.sendMessageToDevice("h")
            avoid_car_outle.backgroundColor = UIColor.init(white: 0.5, alpha: 0.5)
            follow_car_outle.isEnabled = false
            track_car_outle.isEnabled = false
        }
        else{
            serial.sendMessageToDevice("S")
            avoid_car_outle.backgroundColor = UIColor.init(white: 1, alpha: 0)
            avoid_flag = 0
            follow_car_outle.isEnabled = true
            track_car_outle.isEnabled = true
        }
    }
    
    //跟随小车
    var follow_flag = 0
    @IBAction func follow_car(_ sender: UIButton) {
        follow_flag += 1
        if(follow_flag == 1)
        {
            serial.sendMessageToDevice("i")
            follow_car_outle.backgroundColor = UIColor.init(white: 0.5, alpha: 0.5)
            avoid_car_outle.isEnabled = false
            track_car_outle.isEnabled = false
        }
        else{
            serial.sendMessageToDevice("S")
            follow_car_outle.backgroundColor = UIColor.init(white: 1, alpha: 0)
            follow_flag = 0
            avoid_car_outle.isEnabled = true
            track_car_outle.isEnabled = true
        }
    }
    
    //循迹小车
    var track_flag = 0
    @IBAction func track_car(_ sender: UIButton) {
        track_flag += 1
        if(track_flag == 1)
        {
            serial.sendMessageToDevice("j")
            track_car_outle.backgroundColor = UIColor.init(white: 0.5, alpha: 0.5)
            follow_car_outle.isEnabled = false
            avoid_car_outle.isEnabled = false
        }
        else{
            serial.sendMessageToDevice("S")
            track_car_outle.backgroundColor = UIColor.init(white: 1, alpha: 0)
            track_flag = 0
            follow_car_outle.isEnabled = true
            avoid_car_outle.isEnabled = true
        }
    }

}
