//
//  ViewController.swift
//  IoT keyes
//
//  Created by lisagu on 2019/9/11.
//  Copyright © 2019 xiuxian. All rights reserved.
//


import UIKit
import CoreBluetooth
import QuartzCore
import CoreMotion
import Speech


//超声波停止
var flag2 = 0

/// The option to add a \n or \r or \r\n to the end of the send message；将\n或\r或\r\n添加到发送消息结尾的选项
enum MessageOption: Int {
    case noLineEnding,
    newline,
    carriageReturn,
    carriageReturnAndNewline
}

/// The option to add a \n to the end of the received message (to make it more readable)；将\n添加到接收消息末尾的选项（使其更可读）
enum ReceivedMessageOption: Int {
    case none,
    newline
}

//添加文本框代理协议UITextFieldFelegate
final class ViewController: UIViewController, UITextFieldDelegate, BluetoothSerialDelegate, SFSpeechRecognizerDelegate {
    
    //获取AppDelegate对象(为了实现横屏）
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    
    //
    var motionManager:CMMotionManager!
    //var label:UILabel!
    
    //MARK: IBOutlet
    
    
    //@IBOutlet weak var label: UILabel!
    //@IBOutlet weak var Label01: UILabel!
    
    
    //@IBOutlet weak var listenText: UITextView
    
    @IBOutlet weak var disconnect: UIButton!
    @IBOutlet weak var mainTextView: UITextView!   //app接收显示
    //@IBOutlet weak var messageField: UITextField!
    @IBOutlet weak var bottomView: UIView!
    @IBOutlet weak var bottomConstraint: NSLayoutConstraint! // used to move the textField up when the keyboard is present
    @IBOutlet weak var barButton: UIBarButtonItem!
    @IBOutlet weak var navItem: UINavigationItem!
    
    @IBOutlet weak var up_input: NSLayoutConstraint!
    
    //文本输入
    @IBOutlet weak var input_text: UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
       
        ///////////////手机姿态传感器////////////
        motionManager = CMMotionManager()
        motionManager.accelerometerUpdateInterval = 0.1
        
        // init serial
        serial = BluetoothSerial(delegate: self)
        
        // UI
        //mainTextView.text = ""
        reloadView()
        
        NotificationCenter.default.addObserver(self, selector: #selector(ViewController.reloadView), name: NSNotification.Name(rawValue: "reloadStartViewController"), object: nil)
    }
    
    //点击空白处隐藏键盘
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    
    
    func keyboardWillShow(_ notification: Notification) {
        // animate the text field to stay above the keyboard
        var info = (notification as NSNotification).userInfo!
        let value = info[UIResponder.keyboardFrameEndUserInfoKey] as! NSValue
        let keyboardFrame = value.cgRectValue
        
        //TODO: Not animating properly
        UIView.animate(withDuration: 1, delay: 0, options: UIView.AnimationOptions(), animations: { () -> Void in
            self.up_input.constant = keyboardFrame.size.height
        }, completion: { Bool -> Void in
            //self.textViewScrollToBottom()
        })
    }
    
    func keyboardWillHide(_ notification: Notification) {
        // bring the text field back down..
        UIView.animate(withDuration: 1, delay: 0, options: UIView.AnimationOptions(), animations: { () -> Void in
            self.up_input.constant = 0
        }, completion: nil)
        
    }
    
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    /*func keyboardWillShow(_ notification: Notification) {
     // animate the text field to stay above the keyboard
     var info = (notification as NSNotification).userInfo!
     let value = info[UIKeyboardFrameEndUserInfoKey] as! NSValue
     let keyboardFrame = value.cgRectValue
     
     //TODO: Not animating properly
     UIView.animate(withDuration: 1, delay: 0, options: UIViewAnimationOptions(), animations: { () -> Void in
     self.bottomConstraint.constant = keyboardFrame.size.height
     }, completion: { Bool -> Void in
     self.textViewScrollToBottom()
     })
     }
     
     func keyboardWillHide(_ notification: Notification) {
     // bring the text field back down..
     UIView.animate(withDuration: 1, delay: 0, options: UIViewAnimationOptions(), animations: { () -> Void in
     self.bottomConstraint.constant = 0
     }, completion: nil)
     
     }*/
    
    @objc func reloadView() {
        // in case we're the visible view again；以防我们再次成为可视视图
        serial.delegate = self
        
        if serial.isReady {   //如果连接成功
            navItem.title = serial.connectedPeripheral!.name  //标题显示为连接蓝牙的名字
            //barButton.title = "Disconnect"      //左上角按钮名字改为 Disconnect
            barButton.tintColor = UIColor.green   //按钮字体颜色为红色
            barButton.isEnabled = true        //可被按下状态
        } else if serial.centralManager.state == .poweredOn {   //如果蓝牙打开了
            navItem.title = "Bluetooth Serial"
            barButton.title = "Connect"
            barButton.tintColor = view.tintColor
            barButton.isEnabled = true
        } else {           //蓝牙没打开
            navItem.title = "Bluetooth Serial"
            barButton.title = "Connect"
            barButton.tintColor = view.tintColor
            barButton.isEnabled = false     //按钮不可被点击
        }
    }
    
    
   
    
    
    //MARK: BluetoothSerialDelegate
    
    func serialDidReceiveString(_ message: String) {
        // add the received text to the textView, optionally with a line break at the end；/将接收到的文本添加到文本视图中，可以选择在末尾加一个换行符
        if message == "99999"
        {

        }
    }
    
    func serialDidDisconnect(_ peripheral: CBPeripheral, error: NSError?) {   //断开蓝牙
        reloadView()
        // dismissKeyboard()  //这个方法是取消第一响应者状态的
        let hud = MBProgressHUD.showAdded(to: view, animated: true)
        hud?.mode = MBProgressHUDMode.text
        hud?.labelText = "Disconnected"   //屏幕中显示  Disconnected
        hud?.hide(true, afterDelay: 1.0)   //显示1.0秒后隐藏
    }
    
    func serialDidChangeState() {  //蓝牙状态改变
        reloadView()
        if serial.centralManager.state != .poweredOn {  //蓝牙被关闭
            //dismissKeyboard()  //这个方法是取消第一响应者状态的
            let hud = MBProgressHUD.showAdded(to: view, animated: true)
            hud?.mode = MBProgressHUDMode.text
            hud?.labelText = "Bluetooth turned off"   //屏幕中显示  Bluetooth turned off
            hud?.hide(true, afterDelay: 1.0)
        }
    }
    
    
    //MARK: UITextFieldDelegate
    //添加一个代理方法，当键盘的回车键被按下时，执行
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if !serial.isReady {    //如果没有连接成功
            let alert = UIAlertController(title: "Not connected", message: "What am I supposed to send this to?", preferredStyle: .alert)   //发送文本时，会弹出一个显示框，显示标题为Not connected，信息为What am I supposed to send this to?
            alert.addAction(UIAlertAction(title: "Dismiss", style: UIAlertAction.Style.default, handler: { action -> Void in self.dismiss(animated: true, completion: nil) })) //显示一个按钮，标题为Dismiss，按下就退出这个显示框
            present(alert, animated: true, completion: nil)
            //input_text.resignFirstResponder()  //这个方法是取消第一响应者状态的，就是先打开键盘，点击键盘区域以外，就暂时隐藏键盘
            //messageField.resignFirstResponder()  //这个方法是取消第一响应者状态的，就是先打开键盘，点击键盘区域以外，就暂时隐藏键盘
            return true
        }
        
        // send the message to the bluetooth device  发送信息到蓝牙设备
        // but fist, add optionally a line break or carriage return (or both) to the message但首先，可以选择在消息中添加换行符或回车符（或两者都添加）
        let pref = UserDefaults.standard.integer(forKey: MessageOptionKey)
        //var msg = messageField.text!
        var msg = input_text.text!
        
        switch pref {
        case MessageOption.newline.rawValue:
            msg += "\n"
            
        case MessageOption.carriageReturn.rawValue:
            msg += "\r"
            
        case MessageOption.carriageReturnAndNewline.rawValue:
            msg += "\r\n"
            
        default:
            msg += ""
            
        }
        // send the message and clear the textfield  发送消息并清除文本字段
        serial.sendMessageToDevice("$")
        serial.sendMessageToDevice(msg)  //发送信息
        serial.sendMessageToDevice("#")
        //messageField.text = ""    //清空文本
        input_text.text = ""    //清空文本
        return true
    }
    
    
    //MARK: IBActions
    
    @IBAction func barButtonPressed(_ sender: AnyObject) {
        if serial.connectedPeripheral == nil {    //如果还没选择连接到蓝牙
            performSegue(withIdentifier: "ShowScanner", sender: self)   //切换到scanner界面
        }
        //else {     //如果本来已经连接蓝牙了，再点击
        //    serial.disconnect()    //断开蓝牙连接
        //     reloadView()
        // }
        
    }
    @IBAction func disconnect(_ sender: Any) {
        serial.disconnect()    //断开蓝牙连接
        reloadView()
    }

}


