//
//  NeoViewController.swift
//  Motorhome
//
//  Created by lisagu on 2021/1/19.
//  Copyright © 2021 xiuxian. All rights reserved.
//

import UIKit
import CoreBluetooth   //申明蓝牙库文件

class NeoViewController: UIViewController, UITextFieldDelegate, BluetoothSerialDelegate {
    
    func serialDidChangeState() {
        //reloadView()
        // dismissKeyboard()  //这个方法是取消第一响应者状态的
        let hud = MBProgressHUD.showAdded(to: view, animated: true)
        hud?.mode = MBProgressHUDMode.text
        hud?.labelText = "Disconnected"   //屏幕中显示  Disconnected
        hud?.hide(true, afterDelay: 1.0)   //显示1.0秒后隐藏
    }
    
    func serialDidDisconnect(_ peripheral: CBPeripheral, error: NSError?) {
        // reloadView()
        if serial.centralManager.state != .poweredOn {  //蓝牙被关闭
            //dismissKeyboard()  //这个方法是取消第一响应者状态的
            let hud = MBProgressHUD.showAdded(to: view, animated: true)
            hud?.mode = MBProgressHUDMode.text
            hud?.labelText = "Bluetooth turned off"   //屏幕中显示  Bluetooth turned off
            hud?.hide(true, afterDelay: 1.0)
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func neo_add_down(_ sender: UIButton) {
        serial.sendMessageToDevice("o")
    }
    @IBAction func neo_add_up(_ sender: UIButton) {
        serial.sendMessageToDevice("r")
    }
    @IBAction func neo_sub_down(_ sender: UIButton) {
        serial.sendMessageToDevice("p")
    }
    @IBAction func neo_sub_up(_ sender: UIButton) {
        serial.sendMessageToDevice("r")
    }
    @IBAction func neo_stop_down(_ sender: UIButton) {
        serial.sendMessageToDevice("q")
    }
    @IBAction func neo_stop_up(_ sender: UIButton) {
        serial.sendMessageToDevice("r")
    }

}
